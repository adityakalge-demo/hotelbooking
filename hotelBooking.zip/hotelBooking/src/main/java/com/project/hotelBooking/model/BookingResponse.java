package com.project.hotelBooking.model;

public class BookingResponse {
	
	

}
